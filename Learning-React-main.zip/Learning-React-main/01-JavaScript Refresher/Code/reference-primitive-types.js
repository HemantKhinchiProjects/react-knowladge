// primitive
const num1 = 1;
const num2 = num1;
console.log(num2);

// reference

const person1 = { name: "max" };
const person2 = person1;
console.log(person2);

const callMe = (name) => {
  console.log(name);
};
